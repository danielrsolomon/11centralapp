# Implementation plan

Below is the step-by-step implementation plan based on the project details and requirements for the E11EVEN Central App.

## Phase 1: Environment Setup

1.  **Step 1:** Verify that Node.js is installed by running `node -v`. If not installed, install the compatible LTS version (as required by Vite.js projects) (**Project Overview: Core Tools**).
2.  **Step 2:** Initialize a new Vite project configured for React and TypeScript by running:

`npm create vite@latest E11EVEN-Central -- --template react-ts `(**Tech Stack: Vite js, Typescript**).

1.  **Step 3:** Navigate into the project directory (`cd E11EVEN-Central`) and install dependencies with `npm install` (**Tech Stack: Vite js**).
2.  **Step 4:** Install Tailwind CSS, PostCSS, and Autoprefixer following the Tailwind CSS installation guide. Create the configuration file `tailwind.config.js` in the root directory (**Tech Stack: Tailwind CSS**).
3.  **Step 5:** Configure Tailwind CSS to use the provided theming with primary color Gold (#AE9773) and support dark/light modes. Edit the `tailwind.config.js` and add custom theme settings (**Visual Design: Theming & Branding**).
4.  **Step 6:** Install Shadcn UI components per the documentation and integrate it into the project. Ensure components will be used as the base for UI widgets (**Tech Stack: Shadcn UI**).
5.  **Step 7:** Set up a new Git repository with `main` and `dev` branches along with branch protection on GitHub (**Project Overview: Deployment & CI/CD**).
6.  **Step 8:** **Validation:** Run `node -v` and verify the Tailwind CSS setup by adding a test class in an index component.

## Phase 2: Frontend Development

1.  **Step 9:** Create the primary layout component for the application at `/src/components/Layout.tsx`. This layout should include a responsive header and side navigation supporting role-based menu items (**Visual Design: Responsive Design, Accessibility; Project Overview: User Roles**).

2.  **Step 10:** Develop the Header component at `/src/components/Header.tsx` displaying the application branding using primary color Gold (#AE9773) and primary font Geist Sans, and include toggles for light/dark mode (**Visual Design: Branding & Theming**).

3.  **Step 11:** Create a Sidebar component at `/src/components/Sidebar.tsx` that conditionally shows navigation items (for modules: LMS, Connect, Scheduling, Gratuity, Admin Dashboard) based on user roles (**Project Overview: User Roles**).

4.  **Step 12:** Develop the LMS module components:

    *   Create `/src/components/lms/ProgramList.tsx` to list available programs.
    *   Create `/src/components/lms/CourseList.tsx` to display courses under a selected program.
    *   Create `/src/components/lms/ModuleViewer.tsx` to render modules and lessons with support for external video embeds and PDF viewers (**Project Overview: E11EVEN University LMS**).

5.  **Step 13:** Integrate React Hook Form and Zod for LMS forms in `/src/components/lms/LessonForm.tsx` to handle content submissions with client-side validation (**Tech Stack: React Hook Form, Zod; Key Requirements: Data Validation**).

6.  **Step 14:** Build the Connect (Messaging) module UI:

    *   Create `/src/components/messaging/ChannelList.tsx` to display available channels.
    *   Create `/src/components/messaging/ChatWindow.tsx` for direct messaging functionality with real-time updates (**Project Overview: Connect (Messaging System)**).

7.  **Step 15:** Develop file upload components in `/src/components/common/FileUploader.tsx` to support image (JPEG, JPG, PNG - up to 5MB) and document uploads for LMS content (**Project Overview: LMS - Image Uploads**).

8.  **Step 16:** Implement the Scheduling System UI with drag-and-drop functionality:

    *   Create `/src/components/scheduling/ShiftScheduler.tsx` for shift scheduling.
    *   Create `/src/components/scheduling/FloorplanDesigner.tsx` to support floorplan assignment including draggable zones and stations (**Project Overview: Scheduling System & Floorplan Automation**).

9.  **Step 17:** Build the Gratuity Tracking UI:

    *   Create `/src/components/gratuity/TipDashboard.tsx` to display tip reports and allocation metrics in real time (**Project Overview: Gratuity Tracking System**).

10. **Step 18:** Develop the Administrative Dashboard UI at `/src/views/AdminDashboard.tsx` that aggregates KPIs such as training completion, shift coverage, tip pooling, and messaging engagement (**Project Overview: Administrative Dashboard**).

11. **Step 19:** **Validation:** Test each UI component manually in the browser ensuring proper responsive behavior and accessibility (e.g., high contrast modes, reduced motion) as per requirements.

## Phase 3: Backend Development

1.  **Step 20:** Create a `/backend` directory at the root of the project to house backend code. This backend will expose RESTful API endpoints and interact with Supabase services (**Tech Stack: Supabase**).

2.  **Step 21:** Initialize a Node.js project in the `/backend` directory with TypeScript support by running `npm init -y` and installing necessary packages such as Express, Zod, and the Supabase client (**Tech Stack: Typescript, Supabase**).

3.  **Step 22:** Set up a TypeScript configuration file (`tsconfig.json`) in the `/backend` directory for backend development (**Tech Stack: Typescript**).

4.  **Step 23:** Create an Express server in `/backend/server.ts` to serve as the entry point for API endpoints (**Backend: API Servers**).

5.  **Step 24:** Implement secure, role-based authentication middleware in `/backend/middleware/auth.ts` using Supabase's authentication utilities to verify JWT tokens and enforce role permissions (**Key Requirements: Security, User Roles**).

6.  **Step 25:** Develop API endpoints for the LMS module:

    *   Create `/backend/routes/lms.ts` that includes CRUD operations for Programs, Courses, Modules & Lessons with Zod validation for incoming requests (**Project Overview: E11EVEN University LMS, Data Validation**).

7.  **Step 26:** Develop API endpoints for the Connect (Messaging) module:

    *   Create `/backend/routes/messaging.ts` to manage channels, direct messages, and file sharing.
    *   Include configurations for chat history retention (configurable periods of 30, 60, 90 days) and encryption checks (**Project Overview: Connect (Messaging System), Data Encryption**).

8.  **Step 27:** Develop API endpoints for the Scheduling System:

    *   Create `/backend/routes/scheduling.ts` to handle shift schedule management and floorplan assignments.
    *   Integrate the OpenAI API within this file (configure API calls to generate shift schedules based on historical data) (**Project Overview: Scheduling System, OpenAI API Integration**).

9.  **Step 28:** Develop API endpoints for the Gratuity Tracking module:

    *   Create `/backend/routes/gratuity.ts` to manage tip pooling and reporting.
    *   Implement integration with the Micros Symphony API to pull POS data (**Project Overview: Gratuity Tracking System, Micros Symphony API**).

10. **Step 29:** Create a centralized error-handling middleware in `/backend/middleware/errorHandler.ts` to catch and log errors, returning informative messages to clients (**Key Requirements: Error Handling**).

11. **Step 30:** **Validation:** Write and run unit tests (using a framework like Jest) for each endpoint to ensure they return the expected HTTP responses (e.g., `npm test` targeting `/backend/tests/` endpoints).

## Phase 4: Integration

1.  **Step 31:** In the frontend, create a dedicated service folder at `/src/services/` and add an `apiClient.ts` that abstracts API calls using `fetch` or Axios. Configure base URL for the backend endpoints (**Project Overview: Integration, API Calls**).

2.  **Step 32:** Integrate role-based session management in the frontend by using Supabase's client authentication methods. Create `/src/services/auth.ts` to manage login sessions and token storage (**Tech Stack: Supabase Authentication**).

3.  **Step 33:** Wire up each module’s frontend components to their corresponding backend endpoints:

    *   LMS components to `/api/lms` endpoints.
    *   Messaging components to `/api/messaging` endpoints.
    *   Scheduling and Floorplan components to `/api/scheduling` endpoints.
    *   Gratuity Tracking components to `/api/gratuity` endpoints. (**Project Overview: Module Integrations**).

4.  **Step 34:** Ensure that error messages from the backend (via middleware) are caught and displayed in the UI using global error handlers in React (e.g., via ErrorBoundary components) (**Key Requirements: Error Handling**).

5.  **Step 35:** **Validation:** Manually test the integration by performing actions in the UI (login, submit a form, schedule a shift) and confirming the correct API responses using browser dev tools and Postman.

## Phase 5: Deployment

1.  **Step 36:** Set up a CI/CD pipeline using your preferred CI tool (e.g., GitHub Actions). Add a config file (e.g., `.github/workflows/ci.yml`) that runs linting, testing, and builds for both `/` and `/backend` directories (**Project Overview: Deployment & CI/CD**).
2.  **Step 37:** For frontend deployment, build a production version of the app by running `npm run build` in the project root (Vite handles optimized bundling) (**Tech Stack: Vite js**).
3.  **Step 38:** Deploy the production build to your chosen hosting platform. For example, deploy the frontend to Vercel (or an equivalent static hosting service) with proper environment variables (**Project Overview: Deployment**).
4.  **Step 39:** Deploy the backend API to a stable and scalable platform. If using Supabase edge functions for serverless deployment or a containerized service, create necessary deployment configuration files (e.g., Dockerfile, or Supabase function configuration in `/supabase/functions`) (**Tech Stack: Supabase, Deployment**).
5.  **Step 40:** Configure environment variables for integration with external services: OpenAI API keys, Micros Symphony API credentials, and Supabase credentials. Store these securely in the hosting platforms’ secrets management (**Key Requirements: Security, Integrations**).
6.  **Step 41:** **Validation:** After deployment, run end-to-end tests (using a tool like Cypress) against the production URL to verify that all modules (LMS, Messaging, Scheduling, Gratuity Tracking, Dashboard) function correctly.
7.  **Step 42:** Monitor logs and analytics post-deployment to ensure the app meets performance, security, and compliance requirements. Set alerts for critical issues like authentication failures or API errors (**Key Requirements: Scalability, Compliance**).

Each step above is directly aligned with requirements from the project overview and technical specifications. Follow these steps in order and run the validations as indicated to ensure a robust, secure, and scalable implementation of the E11EVEN Central App.
