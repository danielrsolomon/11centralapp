# E11EVEN Central App Project Requirements Document

This document describes the E11EVEN Central App, covering its purpose and the features for its initial version. It outlines each module, necessary integrations, and the underlying technical stack. The app is meant to consolidate workforce management tasks—training, messaging, scheduling, tip tracking, and administration—into one unified platform to streamline operations for both employees and managers.

The primary goal is to deliver an enterprise-level platform that centralizes critical operational functions under a single umbrella. Features like E11EVEN University for staff training, real-time messaging, AI-enhanced scheduling with floorplan assignments, and automated gratuity management are specifically designed to boost efficiency, transparency, and user-friendly interactions. Project success is gauged through enhanced operational efficiency, improved user engagement across modules, and precise financial and scheduling reporting compliant with industry standards.

## In-Scope vs. Out-of-Scope

### In-Scope

*   **E11EVEN University LMS:**

    *   Hierarchical content including programs, courses, modules, and lessons.
    *   Support for multimedia (externally hosted videos, embedded PDFs, image galleries restricted to 5MB JPEG/JPG/PNG).
    *   Interactive quizzes with immediate feedback.
    *   Progress tracking and automatic certification upon course completion.
    *   Role-based content access for different user roles, including department-specific content visibility.
    *   Form management with robust validation using React Hook Form and Zod.

*   **Connect (Messaging System):**

    *   Public and private messaging channels, direct messaging with thread capability.
    *   Real-time notifications, read receipts, and configurable message history (30-90 days).
    *   File sharing across channels, including search capabilities.
    *   Integration with scheduling for alerts on time-off requests.

*   **Scheduling System with AI Integration:**

    *   Drag-and-drop schedule management for daily, weekly, and monthly views.
    *   AI-assisted scheduling powered by OpenAI API, considering historical data, availability, laws, and rules.
    *   Management options for employee availability, time-off, and shift swaps.
    *   Automated floorplan assignments using AI, with interactive floorplans for manual adjustments.

*   **Gratuity Tracking System:**

    *   Automated tip pooling and distribution with configurable rules.
    *   Financial reporting compliant with IRS standards (tip reporting, FLSA compliance).
    *   Payroll system integration for tax withholdings and reporting.
    *   Real-time tip monitoring dashboards for individual and department levels.

*   **Administrative Dashboard:**

    *   Centralized user, role, and department management.
    *   Unified reporting on training, scheduling, tips, and messaging engagement.
    *   Exportable analytics (CSV/PDF).

*   **Visual Design & Responsive Experience:**

    *   Modern interfaces using Tailwind CSS, supporting light/dark modes.
    *   Responsive framework compatible across desktops, tablets, and mobiles.

*   **Third-Party Integrations:**

    *   OpenAI API for scheduling.
    *   Micros Symphony API for POS and hospitality.
    *   ERP, HR, and payroll systems for extended capabilities.

### Out-of-Scope

*   Initial release excludes native or hybrid mobile apps (focus on responsive web access).
*   Offline functionalities or progressive web app (PWA) adaptations.
*   Custom integrations beyond the specified ERP, CRM, or BI tools.
*   Excessive custom rule adjustments (future phases will refine and add parameters).

## User Flow

On first access, users encounter a secure login, supporting role-based authentication. Dependent on their role—SuperAdmin, Admin, Director, Senior Manager, Training Manager, Manager, Lead, Staff—they are directed to their personalized dashboard. A sidebar lists core functions like LMS, messaging, scheduling, gratuity tracking, and administration, whereas the header contains the company logo, venue selector, and account details. Whether using a desktop or a mobile device, users enjoy a straightforward user experience.

Post-login actions are role and module-specific. For instance, staff may explore training in the LMS, communicate via messaging, and review their shifts through the scheduling system. Managers gain additional utilities like approving requests and accessing administrative dashboards. Each interaction is designed to be intuitive with easy scheduling modifications and real-time updates, ensuring swift decision-making and access to detailed reporting.

## Department Structure

The app will support several departments, each catering to specific operational needs within the business:

*   VIP Hosts
*   Guardians
*   Bar Staff
*   Cocktail Staff
*   Server Assistants / Porters
*   Guest Services / Palladium
*   Back Door
*   Management
*   Auditors
*   House Person
*   Corporate Staff
*   Marketing
*   Warehouse / Inventory
*   Maintenance
*   Human Resources
*   All Staff (all departments)

Upon user onboarding, they are assigned an access level (SuperAdmin, Admin, Director, Senior Manager, Training Manager, Manager, Lead, Staff) and associated with one or more departments, determining their content access and visibility within the app.

## Core Features

*   **E11EVEN University LMS** • Hierarchical training content management. • Multimedia-rich courses. • Interactive learning assessments. • Automated progress and certification tracking. • Customized visibility based on roles and departments.
*   **Connect (Messaging System)** • Robust channels for team collaboration. • Data protection with configurable retention. • File sharing and efficient search. • Privacy settings ensuring compliance.
*   **Scheduling System with AI Integration** • Flexible views and drag-and-drop ease. • AI-suggested shifts using comprehensive data analysis. • Real-time employee and shift management. • Integration with automated floorplan tools.
*   **Floorplan Assignment Automation** • Zone mapping and interactive station management. • AI-powered staff and station matchmaking. • User-friendly visual adjustment tools. • Continuous automated rotations and updates.
*   **Gratuity Tracking System** • Customizable tip handling. • Compliance-assured financial documentation. • Payroll integration for real-time taxation. • Complete gratuity transparency and reporting.
*   **Administrative Dashboard and Reporting** • All-encompassing user management interface. • Comprehensive real-time analytics delivery. • Configurable system preferences. • Adaptability for third-party integration expansions.

## Tech Stack & Tools

*   **Frontend:** • Vite.js for build and bundle processes. • React and Typescript for composable UI. • Tailwind CSS for design, featuring customized components. • UI construction with Shadcn components. • React Hook Form with Zod for validation integrity.
*   **Backend & Database:** • Real-time services powered by Supabase. • Micros Symphony POS API integration. • AI support via OpenAI API.
*   **Third-Party Tools & Integrations:** • OpenAI for smart scheduling. • Integration with deeply connected systems like ERP, HR (e.g., ADP), ensuring operational synergy.
*   **IDE & Plugin Integration:** • Cursor for optimized development experiences with AI. • Optional plugins like Windsurf for streamlined collaboration.

## Non-Functional Requirements

*   **Performance:** • Seamless loading and fluid interaction in schedules and assignments. • Real-time update minimal latency in messaging.
*   **Security:** • Secure encryptions in transit and storage. • Role-based access controls and regular compliance checks.
*   **Usability:** • Mobile-first, adaptable interfaces. • Engaging yet accessible navigation features.
*   **Compliance:** • Scheduling and tip management laws are adhered to strictly. • Full federal tax law and GDPR compliance.
*   **Scalability:** • Capacity to scale in response to growing user and data needs. • Modular framework for future functionality and system integrations.

## Constraints & Assumptions

*   The platform is initially for web use with a responsive approach.
*   Functionality depends on certain third-party service availability and constraints.
*   Custom roles are limited to current specifications.
*   Multimedia handling limits based on file-size and external hosting constraints.
*   System performance relies on a stable network infrastructure for real-time updates.
*   AI scheduling requires predefined rules with potential for iterative updates.

## Known Issues & Potential Pitfalls

*   **Integration Complexity:** • Consolidating varied modules demands clear code and API practices. • Third-party API delays may affect the app's real-time features.
*   **Performance Overhead:** • Heavy use in AI and messaging might stress system resources, needing cautious caching and load management.
*   **Data Privacy & Compliance:** • Compliance with regulations demands ongoing diligence and encrypted data assurance.
*   **User Experience on Multiple Devices:** • Ensures broad device compatibility through responsive design and comprehensive UX testing.
*   **Error Handling & Offline States:** • Implementing solid fallback and messaging measures for potential errors or connectivity issues is crucial.

This PRD is the foundational point for following technical documentation, including Tech Stack Analyses, Frontend and Backend guidelines, and Implementation Strategies. It clarifies project expectations to reduce ambiguity and establish a robust base for developing the E11EVEN Central App.
